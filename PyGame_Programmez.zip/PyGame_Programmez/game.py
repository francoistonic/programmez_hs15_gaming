import pygame
from Player import Player
from Enemy import Enemy
from Wall import Wall
from Item import Item
from Labyrinth import Labyrinth

# initialisation de la librairie
pygame.init()

background_color = (255, 255, 255)
speed = 64
 
# spécification de la resolution 1280 pixels sur 720
screen = pygame.display.set_mode((1280, 720))
screen.fill(background_color)

# initialisation d’un booléen pour la boucle infinie
running = True

# instanciation des sprites
player = Player()
wall = Wall()

# le groupe de sprite
sprites_group = pygame.sprite.Group()
sprites_group.add(player)

# structure de données du labyrinthe
labyrinth_array = [
 [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
 [1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 0, 3, 0, 0, 0, 1],
 [1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1],
 [1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],
 [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1],
 [1, 0, 1, 0, 1, 3, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 4, 1, 0, 1],
 [1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1],
 [1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1],
 [1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1],
 [1, 0, 0, 4, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
 [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

# le groupe de sprites du labyrinth
labyrinth_group = pygame.sprite.Group()

# le groupe des objets à ramasser
item_group = pygame.sprite.Group()

# instanciation du labyrinth
labyrinth = Labyrinth(labyrinth_array, 64, 64)

# lecture et affichage du labyrinthe
labyrinth.read_and_display(labyrinth_group, item_group)
labyrinth_group.draw(screen)

# copie du labyrinthe en mémoire
labyrinth_background = screen.copy()

# initialisation des effets sonores
pygame.mixer.init()
beep_sound = pygame.mixer.Sound("./asset/sound/beep.ogg")

# countdown
countdown = 6000

# les polices de caractères
game_font_chrono = pygame.freetype.Font("./asset/font/badaboom/badaboom.ttf", 40)
game_font_win_lost = pygame.freetype.Font("./asset/font/badaboom/badaboom.ttf", 100)

# événement utilisateur
clock_event = pygame.USEREVENT + 1

# lancement de l'événement toutes les 100 millisecondes
pygame.time.set_timer(clock_event, 100)

# la boucle infinie
while running:

    pygame.time.Clock().tick(25)
    
    # affichage de la copie mémoire du labyrinthe
    screen.blit(labyrinth_background,(0,0))

    for event in pygame.event.get():
        # capture de la touche ESC pour sortir de la boucle
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False
        
        # capture de l'événement clock_event pour mettre à jour le compte à rebours
        if event.type == clock_event and countdown >= 0 and len(item_group) > 0:
            countdown -= 10
            countdown_second = int(countdown/100)
            countdown_hundredth = int(countdown - countdown_second*100)
            countdown_display = str(countdown_second) + ":" + str(countdown_hundredth)
            game_font_chrono.render_to(screen, (10,15), countdown_display, (255,0,0))

    # capture des touches de contrôle du joueur
    keys = pygame.key.get_pressed()
    if keys[pygame.K_q]:
        player.move_left(speed)
    elif keys[pygame.K_z]:
        player.move_up(speed)
    elif keys[pygame.K_s]:
        player.move_down(speed)
    elif keys[pygame.K_d]:
        player.move_right(speed)

    # le son lors du ramassage d'un objet    
    if pygame.sprite.spritecollide(player, item_group, True):
        beep_sound.play()

    # plus d'objets => GAGNE
    if len(item_group) == 0:
        game_font_win_lost.render_to(screen, (500,300), "GAGNE", (0,0,255))

    # chrono à 0 => PERDU
    if countdown <= 0:
        game_font_win_lost.render_to(screen, (500,300), "PERDU", (0,0,255))

    # if pygame.sprite.spritecollide(player, labyrinth_group, False):
    if labyrinth_array[int(player.rect.y/64)][int(player.rect.x/64)] == 1:
        player.move_rewind(speed)

    # les instructions opérées sur les objets du jeu
    sprites_group.update()

    # affichage des objets des groupes
    sprites_group.draw(screen)
    item_group.draw(screen)

    # la mise à jour complète de l’affichage
    pygame.display.flip()

# sortie du script
pygame.quit()
