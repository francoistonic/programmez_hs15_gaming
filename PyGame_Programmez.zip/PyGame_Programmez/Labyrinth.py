import pygame
from Wall import Wall
from Item import Item

class Labyrinth():
    def __init__(self, laby_struct, cell_width, cell_height):
        self.labyrinth = laby_struct
        self.cell_width = cell_width
        self.cell_height = cell_height

    def read_and_display(self, wall_sprite_group, item_sprite_group):
        x_pos = 0
        y_pos = 0
        for y in range(len(self.labyrinth)):
            x_pos = 0
            for x in range(len(self.labyrinth[0])):
                if self.labyrinth[y][x] == 1:
                    wall = Wall()
                    wall.rect.x = x_pos
                    wall.rect.y = y_pos
                    wall_sprite_group.add(wall)
                elif self.labyrinth[y][x] == 2:
                    diamond = Item("./asset/images/diamond.png")
                    diamond.rect.x = x_pos
                    diamond.rect.y = y_pos
                    item_sprite_group.add(diamond)
                elif self.labyrinth[y][x] == 3:
                    round = Item("./asset/images/round.png")
                    round.rect.x = x_pos
                    round.rect.y = y_pos
                    item_sprite_group.add(round)
                elif self.labyrinth[y][x] == 4:
                    triangle = Item("./asset/images/triangle.png")
                    triangle.rect.x = x_pos
                    triangle.rect.y = y_pos
                    item_sprite_group.add(triangle)

                x_pos += self.cell_width
            y_pos += self.cell_height
