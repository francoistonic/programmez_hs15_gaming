import pygame
import random
import math 

class Enemy(pygame.sprite.Sprite):
 
 def __init__(self):
  pygame.sprite.Sprite.__init__(self)
  self.image = pygame.image.load("./asset/enemy.png").convert_alpha()
  self.rect = self.image.get_rect()
  self.rect.x = 1152
  self.rect.y = 64
  self.speed = 1
  self.direction = 0 
  self.x_dist = 0
  self.y_dist = 0
  self.speed_x = 0
  self.speed_y = 0
  self.cell_around = [0, 0, 0, 0] # 0 -> E, 1 -> N, 2 -> W, 3 -> S  
  self.current_direction = 0

 def update(self):
  pass
 
 def is_wall_in_front_of(self, area):
  returnValue = False

  match self.current_direction:
     case 1: # W
        if self.case_x < 1 or area[self.case_y][self.case_x - 1] == 1:
           returnValue = True 
     case 2: # N
        if self.case_y < 1 or area[self.case_y-1][self.case_x] == 1:
           returnValue = True
     case 3: # E
        if self.case_x > 18 or area[self.case_y][self.case_x + 1] == 1:
           returnValue = True
     case 4: # S
        if self.case_y > 9 or area[self.case_y + 1][self.case_x] == 1:
           returnValue = True

  print("---- " + str(self.case_x) + " " + str(self.case_y ) + " " + str(returnValue))
  #print("----+++ " + str(self.current_direction) + " " + str(area[self.case_y + 1][self.case_x]))

  return returnValue


 def go_to(self, player, speed, area):
    
    direction_x = None
    direction_y = None

    self.case_x = int(self.rect.x/speed)
    self.case_y = int(self.rect.y/speed)
    print(str(self.case_x) + " " + str(self.case_y) + ' ' + str(self.current_direction))

    if self.current_direction == 0:
        if self.rect.x >= player.rect.x:
            self.x_dist = self.rect.x - player.rect.x
            self.current_direction = 1
        else:
            self.x_dist = player.rect.x - self.rect.x
            self.current_direction = 2

        if self.rect.y >= player.rect.y:
            self.y_dist = self.rect.y - player.rect.y
            self.current_direction = 3
        else:
            self.y_dist = player.rect.y - self.rect.y
            self.current_direction = 4 
    else:
        if not self.is_wall_in_front_of(area):
            print("no wall")
            if self.current_direction == 1:
                self.speed_x = -speed 
                self.speed_y = 0
            elif self.current_direction == 2:
                self.speed_x = 0
                self.speed_y = -speed
            elif self.current_direction == 3:
                self.speed_x = speed
                self.speed_y = 0
            elif self.current_direction == 4:
                self.speed_x = 0
                self.speed_y = speed
        else:   
            print("dir " + str(self.current_direction))
            if self.current_direction != 1 and self.current_direction != 3:
                if self.rect.x > player.rect.x:
                    self.dist_x = self.rect.x - player.rect.x
                    direction_x = 1
            else:
                self.dist_x = player.rect.x - self.rect.x
                direction_x = 3

            if self.current_direction != 2 and self.current_direction != 4:
                if self.rect.y > player.rect.y:
                    self.dist_y = self.rect.y - player.rect.y
                    direction_y = 2
            else:
                self.dist_y = player.rect.y - self.rect.y
                direction_y = 4
           
            if self.dist_x > self.dist_y:
               self.current_direction = direction_x if direction_x != None else direction_y
            else:
               self.current_direction = direction_y if direction_y != None else direction_x
           
    self.rect.x += self.speed_x
    self.rect.y += self.speed_y

    self.speed_x = 0
    self.speed_y = 0










  