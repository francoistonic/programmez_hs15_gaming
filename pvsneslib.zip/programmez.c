/*---------------------------------------------------------------------------------


    Démo pour la magazine Programmez
    -- alekmaul

 Sprite de Stephen "Redshrike" Challener), http://opengameart.org
 Décors créé à partir du logo Programmer du site Web, passé en 16 coulrus

---------------------------------------------------------------------------------*/
#include <snes.h>

extern char spriteg, spriteg_end, spritep, spritep_end;
extern char fondg, fondg_end, fondt, fondt_end, fondp, fondp_end;

#define FRAMES_PER_ANIMATION 3 // 3 sprites par direction

//---------------------------------------------------------------------
// Définitiuon du sprite 
//---------------------------------------------------------------------
typedef struct
{
    s16 x, y;
    u16 gfx_frame;
    u16 anim_frame;
    u8 state;
    u8 flipx;
} Monster;

//---------------------------------------------------------------------
// L'état du sprite (comment il marche)
//---------------------------------------------------------------------
enum SpriteState
{
    W_DOWN = 0,
    W_UP = 1,
    W_RIGHT = 2,
    W_LEFT = 2
};

//---------------------------------------------------------------------
// Limites de l'écran 
//---------------------------------------------------------------------
enum
{
    SCREEN_TOP = -16,
    SCREEN_BOTTOM = 224,
    SCREEN_LEFT = -16,
    SCREEN_RIGHT = 256
};

const char sprTiles[9] =
{
        0, 2, 4, 6, 8, 10, 12, 14, 32
}; // Rappelez vous que les sprites sont entrelacés

unsigned short pad0;
Monster monster = {100, 100};

//---------------------------------------------------------------------------------
int main(void)
{

    // Initialisaiton de la SNES
    consoleInit();

    // Copie des tuiles du décors, et de la palette
    bgInitTileSet(0, &fondg, &fondp, 0, (&fondg_end - &fondg), (&fondp_end - &fondp), BG_16COLORS, 0x4000);

    // Copie de la tilemap en mémoire
    bgInitMapSet(0, &fondt, (&fondt_end - &fondt), SC_32x32, 0x6800);

    // Initialisation du sprite et de sa palette, avec la taile de 16x16 et 32x32
    oamInitGfxSet(&spriteg, (&spriteg_end - &spriteg), &spritep, (&spritep_end - &spritep), 0, 0x0000, OBJ_SIZE16_L32);

    // Définition des paramètres du sprite
    oamSet(0, monster.x, monster.y, 0, 0, 0, 0, 0);
    oamSetEx(0, OBJ_SMALL, OBJ_SHOW);
    oamSetVisible(0, OBJ_SHOW);

    // On se met en mode 1 et on ne garde que le premier plan de décors
    setMode(BG_MODE1, 0);
    bgSetEnable(0);
    bgSetDisable(1);
    bgSetDisable(2);
    setScreenOn();

    // Attente infinie :P
    while (1)
    {
        // Mise à jour des valeurs de la manette et ré"cupération des valeurs du pad #0
        pad0 = padsCurrent(0);

        if (pad0)
        {
            // Mise à jour du psrite suivant la manette
            if (pad0 & KEY_UP)
            {
                if (monster.y >= SCREEN_TOP)
                    monster.y--;
                monster.state = W_UP;
                monster.flipx = 0;
            }
            if (pad0 & KEY_LEFT)
            {
                if (monster.x >= SCREEN_LEFT)
                    monster.x--;
                monster.state = W_LEFT;
                monster.flipx = 1;
            }
            if (pad0 & KEY_RIGHT)
            {
                if (monster.x <= SCREEN_RIGHT)
                    monster.x++;
                monster.state = W_RIGHT;
                monster.flipx = 0;
            }
            if (pad0 & KEY_DOWN)
            {
                if (monster.y <= SCREEN_BOTTOM)
                    monster.y++;
                monster.state = W_DOWN;
                monster.flipx = 0;
            }
            monster.anim_frame++;
            if (monster.anim_frame >= FRAMES_PER_ANIMATION)
                monster.anim_frame = 0;
        }

        // Maintenant, mettre le sprite sur l’écran en ayant récupéré son état
        monster.gfx_frame = sprTiles[monster.anim_frame + monster.state * FRAMES_PER_ANIMATION];
        oamSet(0, monster.x, monster.y, 3, monster.flipx, 0, monster.gfx_frame, 0);

        // Attente du VBlank, et mise à jour su prite aussi  ;-) )
        WaitForVBlank();
    }
    return 0;
}
